// Seed initial data for KisanConnect
const mongodb = require("mongodb")
const { MongoClient } = mongodb

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/kisan-connect"

async function seedData() {
  const client = new MongoClient(MONGODB_URI)

  try {
    await client.connect()
    const db = client.db()

    console.log("Seeding learning modules...")
    const learningModules = [
      {
        title: "Organic Farming Guide",
        category: "organic",
        content: "Learn sustainable farming practices",
        steps: [
          "Prepare soil with compost",
          "Use natural pest control",
          "Implement crop rotation",
          "Avoid synthetic chemicals",
          "Monitor soil health",
        ],
      },
      {
        title: "Mushroom Cultivation",
        category: "mushroom",
        content: "Commercial mushroom growing guide",
        steps: [
          "Select mushroom species",
          "Prepare substrate",
          "Maintain temperature",
          "Monitor contamination",
          "Harvest at right time",
        ],
      },
      {
        title: "Dairy Farming",
        category: "dairy",
        content: "Modern dairy farming techniques",
        steps: [
          "Select quality cattle",
          "Provide nutrition",
          "Maintain hygiene",
          "Regular health checks",
          "Proper storage",
        ],
      },
      {
        title: "Greenhouse Farming",
        category: "greenhouse",
        content: "Protected cultivation methods",
        steps: ["Design greenhouse", "Install irrigation", "Control climate", "Choose crops", "Monitor plants"],
      },
    ]

    await db.collection("learning").insertMany(learningModules)

    console.log("Seeding subsidies...")
    const subsidies = [
      {
        title: "Agricultural Input Subsidy",
        description: "Subsidy for seeds and fertilizers",
        crops: ["Rice", "Wheat", "Corn", "Pulses"],
        districts: ["Kathmandu", "Bhaktapur", "Lalitpur", "Pokhara", "Morang"],
        amount: 50000,
        eligibility: "Small and marginal farmers",
        link: "https://moad.gov.np",
        department: "Ministry of Agriculture",
      },
      {
        title: "Irrigation Development Subsidy",
        description: "Support for irrigation infrastructure",
        crops: ["All crops"],
        districts: ["All"],
        amount: 100000,
        eligibility: "Farmers with 0.5-5 hectares",
        link: "https://moad.gov.np",
        department: "Ministry of Irrigation",
      },
    ]

    await db.collection("subsidies").insertMany(subsidies)

    console.log("Seeding insurance providers...")
    const insurance = [
      {
        provider: "Nepal Insurance Board",
        type: "crop",
        coverage: "Crop damage and loss",
        premium: 5000,
        link: "https://www.nib.com.np",
        phone: "+977-1-4200000",
      },
      {
        provider: "Nepal Agricultural Insurance",
        type: "livestock",
        coverage: "Livestock mortality",
        premium: 10000,
        link: "https://naic.gov.np",
        phone: "+977-1-4400000",
      },
    ]

    await db.collection("insurance").insertMany(insurance)

    console.log("Data seeding complete!")
  } catch (error) {
    console.error("Data seeding failed:", error)
  } finally {
    await client.close()
  }
}

seedData()
