// Initialize MongoDB collections and indexes
// Run this script once to set up the database

const mongodb = require("mongodb")
const { MongoClient } = mongodb

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/kisan-connect"

async function initializeDatabase() {
  const client = new MongoClient(MONGODB_URI)

  try {
    await client.connect()
    const db = client.db()

    console.log("Creating collections...")

    // Users collection
    await db.createCollection("users").catch(() => {})
    await db.collection("users").createIndex({ email: 1 }, { unique: true })
    await db.collection("users").createIndex({ role: 1 })

    // Crops collection
    await db.createCollection("crops").catch(() => {})
    await db.collection("crops").createIndex({ farmerId: 1 })
    await db.collection("crops").createIndex({ category: 1 })
    await db.collection("crops").createIndex({ available: 1 })

    // Orders collection
    await db.createCollection("orders").catch(() => {})
    await db.collection("orders").createIndex({ buyerId: 1 })
    await db.collection("orders").createIndex({ farmerId: 1 })
    await db.collection("orders").createIndex({ status: 1 })

    // Market prices collection
    await db.createCollection("marketPrices").catch(() => {})
    await db.collection("marketPrices").createIndex({ crop: 1, district: 1 })
    await db.collection("marketPrices").createIndex({ timestamp: -1 })

    // Weather collection
    await db.createCollection("weather").catch(() => {})
    await db.collection("weather").createIndex({ region: 1, timestamp: -1 })

    // News collection
    await db.createCollection("news").catch(() => {})
    await db.collection("news").createIndex({ timestamp: -1 })
    await db.collection("news").createIndex({ category: 1 })

    // Learning modules collection
    await db.createCollection("learning").catch(() => {})
    await db.collection("learning").createIndex({ category: 1 })

    // Subsidies collection
    await db.createCollection("subsidies").catch(() => {})
    await db.collection("subsidies").createIndex({ crops: 1 })
    await db.collection("subsidies").createIndex({ districts: 1 })

    // Insurance collection
    await db.createCollection("insurance").catch(() => {})
    await db.collection("insurance").createIndex({ type: 1 })

    console.log("Database initialization complete!")
  } catch (error) {
    console.error("Database initialization failed:", error)
  } finally {
    await client.close()
  }
}

initializeDatabase()
