"use client"

import Link from "next/link"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { LogoIcon } from "@/components/logo"
import { useLanguage } from "@/contexts/language-context"

export default function Navbar() {
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [mounted, setMounted] = useState(false)
  const { language, setLanguage, t } = useLanguage()
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    setMounted(true)
    const darkMode = localStorage.getItem("darkMode") === "true"
    setIsDarkMode(darkMode)
    if (darkMode) {
      document.documentElement.classList.add("dark")
    }

    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
  }, [])

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode
    setIsDarkMode(newDarkMode)
    localStorage.setItem("darkMode", String(newDarkMode))
    if (newDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("user")
    setUser(null)
  }

  if (!mounted) return null

  return (
    <nav className="sticky top-0 z-50 bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground">
              <LogoIcon />
            </div>
            <span className="text-foreground">KisanConnect</span>
          </Link>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="/market-prices" className="text-foreground hover:text-primary transition-colors text-sm">
              {t("market-prices")}
            </Link>
            <Link href="/marketplace" className="text-foreground hover:text-primary transition-colors text-sm">
              {t("marketplace")}
            </Link>
            <Link href="/weather" className="text-foreground hover:text-primary transition-colors text-sm">
              {t("weather")}
            </Link>
            <Link href="/subsidies" className="text-foreground hover:text-primary transition-colors text-sm">
              {t("subsidies")}
            </Link>
            {user && (
              <Link href="/profile" className="text-foreground hover:text-primary transition-colors text-sm">
                {t("profile")}
              </Link>
            )}
          </div>

          {/* Right side actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="flex items-center gap-1 bg-secondary rounded-lg px-2 py-1">
              <button
                onClick={() => setLanguage("en")}
                className={`text-xs font-medium px-2 py-1 rounded transition-colors ${
                  language === "en" ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-muted"
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage("ne")}
                className={`text-xs font-medium px-2 py-1 rounded transition-colors ${
                  language === "ne" ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-muted"
                }`}
              >
                नेपाली
              </button>
            </div>

            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-lg hover:bg-muted transition-colors"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? "☀️" : "🌙"}
            </button>

            {user ? (
              <>
                <div className="flex items-center gap-2 px-3 py-1 bg-muted rounded-lg">
                  <span className="text-sm font-medium">{user.name}</span>
                </div>
                <Button variant="outline" size="sm" onClick={handleLogout}>
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/login">{t("login")}</Link>
                </Button>
                <Button size="sm" className="bg-primary hover:bg-primary/90" asChild>
                  <Link href="/signup">{t("signup")}</Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
