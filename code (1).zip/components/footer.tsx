import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-card border-t border-border py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-semibold mb-3">KisanConnect</h3>
            <p className="text-sm text-muted-foreground">Empowering Nepali farmers with modern technology</p>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Product</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/market-prices" className="hover:text-primary">
                  Market Prices
                </Link>
              </li>
              <li>
                <Link href="/marketplace" className="hover:text-primary">
                  Marketplace
                </Link>
              </li>
              <li>
                <Link href="/weather" className="hover:text-primary">
                  Weather
                </Link>
              </li>
              <li>
                <Link href="/learning" className="hover:text-primary">
                  Learning
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary">
                  About
                </Link>
              </li>
              <li>
                <Link href="/news" className="hover:text-primary">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary">
                  Privacy
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary">
                  Terms
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>© 2025 KisanConnect. All rights reserved. Built for Nepali farmers.</p>
        </div>
      </div>
    </footer>
  )
}
