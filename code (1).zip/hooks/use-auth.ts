// Client-side authentication hook
"use client"

import { useState, useEffect, useCallback } from "react"

interface User {
  userId: string
  email: string
  role: "farmer" | "buyer" | "admin"
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Load user from localStorage on mount
  useEffect(() => {
    const token = localStorage.getItem("auth_token")
    if (token) {
      verifyAuth(token)
    } else {
      setLoading(false)
    }
  }, [])

  const verifyAuth = async (token: string) => {
    try {
      const res = await fetch("/api/auth/verify", {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (res.ok) {
        const data = await res.json()
        setUser(data.user)
      } else {
        localStorage.removeItem("auth_token")
        setUser(null)
      }
    } catch (err) {
      console.error("Auth verification failed:", err)
      setError("Failed to verify authentication")
    } finally {
      setLoading(false)
    }
  }

  const login = useCallback(async (email: string, password: string, role: string) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, role }),
      })
      const data = await res.json()
      if (res.ok) {
        localStorage.setItem("auth_token", data.token)
        setUser(data.user)
        return data
      } else {
        setError(data.error || "Login failed")
        throw new Error(data.error)
      }
    } catch (err) {
      console.error("Login error:", err)
      throw err
    } finally {
      setLoading(false)
    }
  }, [])

  const signup = useCallback(async (email: string, password: string, fullName: string, role: string) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, fullName, role }),
      })
      const data = await res.json()
      if (res.ok) {
        localStorage.setItem("auth_token", data.token)
        setUser(data.user)
        return data
      } else {
        setError(data.error || "Signup failed")
        throw new Error(data.error)
      }
    } catch (err) {
      console.error("Signup error:", err)
      throw err
    } finally {
      setLoading(false)
    }
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem("auth_token")
    setUser(null)
  }, [])

  return {
    user,
    loading,
    error,
    login,
    signup,
    logout,
    isAuthenticated: !!user,
  }
}
