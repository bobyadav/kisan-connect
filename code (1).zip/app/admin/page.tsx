"use client"

import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function AdminPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("users")

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) {
      router.push("/login")
    }
  }, [user, loading, router])

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  if (!user || user.role !== "admin") {
    return null
  }

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Users", value: "0", icon: "👥" },
            { label: "Total Crops", value: "0", icon: "🌾" },
            { label: "Pending Orders", value: "0", icon: "📦" },
            { label: "Total Revenue", value: "₹0", icon: "💹" },
          ].map((stat, idx) => (
            <div key={idx} className="bg-card border border-border rounded-xl p-6">
              <div className="text-3xl mb-2">{stat.icon}</div>
              <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
              <p className="text-2xl font-bold">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-border">
          {["users", "crops", "orders", "news", "content", "analytics"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 border-b-2 transition-colors capitalize ${
                activeTab === tab
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="bg-card border border-border rounded-xl p-6">
          {activeTab === "users" && <UsersTab />}
          {activeTab === "crops" && <CropsTab />}
          {activeTab === "orders" && <OrdersTab />}
          {activeTab === "news" && <NewsTab />}
          {activeTab === "content" && <ContentTab />}
          {activeTab === "analytics" && <AnalyticsTab />}
        </div>
      </div>
    </main>
  )
}

function UsersTab() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">User Management</h3>
      <div className="space-y-3 mb-6">
        <Input type="text" placeholder="Search users..." />
      </div>
      <div className="border border-border rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-muted">
            <tr>
              <th className="px-4 py-2 text-left">Email</th>
              <th className="px-4 py-2 text-left">Role</th>
              <th className="px-4 py-2 text-left">Joined</th>
              <th className="px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-t">
              <td colSpan={4} className="px-4 py-4 text-center text-muted-foreground">
                No users found
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}

function CropsTab() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Crop Listings</h3>
      <p className="text-muted-foreground">Manage all crop listings from farmers</p>
    </div>
  )
}

function OrdersTab() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Order Management</h3>
      <p className="text-muted-foreground">View and manage all orders</p>
    </div>
  )
}

function NewsTab() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">News Management</h3>
      <Button className="mb-4 bg-primary hover:bg-primary/90">Add News Article</Button>
      <p className="text-muted-foreground">Manage and publish news articles</p>
    </div>
  )
}

function ContentTab() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Content Management</h3>
      <p className="text-muted-foreground">Manage learning modules, subsidies, and insurance information</p>
    </div>
  )
}

function AnalyticsTab() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Analytics</h3>
      <p className="text-muted-foreground">Platform analytics and insights</p>
    </div>
  )
}
