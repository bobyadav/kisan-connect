"use client"

import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"

interface InsuranceProvider {
  id: string
  provider: string
  type: "crop" | "livestock" | "property"
  coverage: string
  premium: number
  link: string
  phone: string
}

const insuranceProviders: InsuranceProvider[] = [
  {
    id: "1",
    provider: "Nepal Insurance Board",
    type: "crop",
    coverage: "Comprehensive crop damage coverage including weather, pests, and diseases",
    premium: 5000,
    link: "https://www.nib.com.np",
    phone: "+977-1-4200000",
  },
  {
    id: "2",
    provider: "National Agricultural Insurance Board",
    type: "crop",
    coverage: "Crop insurance for major crops with government support",
    premium: 3500,
    link: "https://naic.gov.np",
    phone: "+977-1-4400000",
  },
  {
    id: "3",
    provider: "Pragati Life Insurance",
    type: "livestock",
    coverage: "Livestock mortality and disease insurance",
    premium: 10000,
    link: "https://www.pragati.com.np",
    phone: "+977-1-5200000",
  },
  {
    id: "4",
    provider: "Nepal Life Insurance Company",
    type: "property",
    coverage: "Farm property and equipment damage protection",
    premium: 8000,
    link: "https://nlicl.com.np",
    phone: "+977-1-4100000",
  },
]

export default function InsurancePage() {
  const cropInsurance = insuranceProviders.filter((p) => p.type === "crop")
  const livestockInsurance = insuranceProviders.filter((p) => p.type === "livestock")
  const propertyInsurance = insuranceProviders.filter((p) => p.type === "property")

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Agricultural Insurance & Government Links</h1>

        {/* Crop Insurance */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Crop Insurance</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {cropInsurance.map((provider) => (
              <div key={provider.id} className="bg-card border border-border rounded-xl p-6">
                <h3 className="text-xl font-semibold mb-2">{provider.provider}</h3>
                <p className="text-foreground mb-4">{provider.coverage}</p>
                <div className="mb-4 space-y-2">
                  <p className="text-sm">
                    <span className="text-muted-foreground">Premium: </span>
                    <span className="font-semibold text-primary">₹{provider.premium}/year</span>
                  </p>
                  <p className="text-sm">
                    <span className="text-muted-foreground">Contact: </span>
                    <a href={`tel:${provider.phone}`} className="font-semibold text-primary hover:underline">
                      {provider.phone}
                    </a>
                  </p>
                </div>
                <Button className="bg-primary hover:bg-primary/90 w-full" asChild>
                  <a href={provider.link} target="_blank" rel="noopener noreferrer">
                    Learn More
                  </a>
                </Button>
              </div>
            ))}
          </div>
        </section>

        {/* Livestock Insurance */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Livestock Insurance</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {livestockInsurance.map((provider) => (
              <div key={provider.id} className="bg-card border border-border rounded-xl p-6">
                <h3 className="text-xl font-semibold mb-2">{provider.provider}</h3>
                <p className="text-foreground mb-4">{provider.coverage}</p>
                <div className="mb-4 space-y-2">
                  <p className="text-sm">
                    <span className="text-muted-foreground">Premium: </span>
                    <span className="font-semibold text-primary">₹{provider.premium}/year</span>
                  </p>
                  <p className="text-sm">
                    <span className="text-muted-foreground">Contact: </span>
                    <a href={`tel:${provider.phone}`} className="font-semibold text-primary hover:underline">
                      {provider.phone}
                    </a>
                  </p>
                </div>
                <Button className="bg-primary hover:bg-primary/90 w-full" asChild>
                  <a href={provider.link} target="_blank" rel="noopener noreferrer">
                    Learn More
                  </a>
                </Button>
              </div>
            ))}
          </div>
        </section>

        {/* Property Insurance */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Property Insurance</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {propertyInsurance.map((provider) => (
              <div key={provider.id} className="bg-card border border-border rounded-xl p-6">
                <h3 className="text-xl font-semibold mb-2">{provider.provider}</h3>
                <p className="text-foreground mb-4">{provider.coverage}</p>
                <div className="mb-4 space-y-2">
                  <p className="text-sm">
                    <span className="text-muted-foreground">Premium: </span>
                    <span className="font-semibold text-primary">₹{provider.premium}/year</span>
                  </p>
                  <p className="text-sm">
                    <span className="text-muted-foreground">Contact: </span>
                    <a href={`tel:${provider.phone}`} className="font-semibold text-primary hover:underline">
                      {provider.phone}
                    </a>
                  </p>
                </div>
                <Button className="bg-primary hover:bg-primary/90 w-full" asChild>
                  <a href={provider.link} target="_blank" rel="noopener noreferrer">
                    Learn More
                  </a>
                </Button>
              </div>
            ))}
          </div>
        </section>

        {/* Government Links */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Official Government Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { name: "Ministry of Agriculture", url: "https://moad.gov.np", icon: "🏛️" },
              { name: "Nepal Agriculture Board", url: "https://nab.gov.np", icon: "🌾" },
              { name: "National Plant Protection Organization", url: "https://nppo.gov.np", icon: "🛡️" },
              { name: "National Cooperatives Bank", url: "https://ncbl.com.np", icon: "🏦" },
              { name: "Nepal Rastra Bank", url: "https://nrb.org.np", icon: "💳" },
              { name: "Agricultural Inputs Company Limited", url: "https://aicl.gov.np", icon: "🥗" },
            ].map((link, idx) => (
              <a
                key={idx}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-card border border-border rounded-xl p-6 hover:shadow-lg transition-shadow flex items-center gap-4"
              >
                <span className="text-4xl">{link.icon}</span>
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{link.name}</p>
                  <p className="text-xs text-primary hover:underline">Visit website →</p>
                </div>
              </a>
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
