"use client"

import { useState } from "react"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"

interface LearningModule {
  id: string
  title: string
  category: "organic" | "mushroom" | "dairy" | "greenhouse"
  content: string
  steps: string[]
  icon: string
}

const modules: LearningModule[] = [
  {
    id: "1",
    title: "Organic Farming Guide",
    category: "organic",
    icon: "🌱",
    content: "Learn sustainable farming practices that improve soil health and crop yield.",
    steps: [
      "Prepare soil with compost and organic matter",
      "Use natural pest control methods",
      "Implement crop rotation systems",
      "Avoid synthetic fertilizers and pesticides",
      "Monitor soil health regularly",
    ],
  },
  {
    id: "2",
    title: "Mushroom Cultivation",
    category: "mushroom",
    icon: "🍄",
    content: "Step-by-step guide to growing mushrooms commercially.",
    steps: [
      "Select suitable mushroom species",
      "Prepare growing substrate",
      "Maintain proper temperature and humidity",
      "Monitor for contamination",
      "Harvest at right time",
    ],
  },
  {
    id: "3",
    title: "Modern Dairy Farming",
    category: "dairy",
    icon: "🐄",
    content: "Modern techniques for efficient dairy farming.",
    steps: [
      "Select quality dairy cattle",
      "Provide balanced nutrition",
      "Maintain proper hygiene",
      "Regular health checkups",
      "Proper milk storage and handling",
    ],
  },
  {
    id: "4",
    title: "Greenhouse Farming",
    category: "greenhouse",
    icon: "🏠",
    content: "Protected cultivation for year-round farming.",
    steps: [
      "Design greenhouse structure",
      "Install irrigation system",
      "Control temperature and humidity",
      "Choose suitable crops",
      "Monitor plant health regularly",
    ],
  },
]

export default function LearningPage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [expandedModule, setExpandedModule] = useState<string | null>(null)

  const filteredModules = selectedCategory ? modules.filter((m) => m.category === selectedCategory) : modules

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Learning Resources</h1>

        {/* Category Filter */}
        <div className="mb-8">
          <label className="text-sm font-medium mb-3 block">Filter by Category</label>
          <div className="flex gap-3 flex-wrap">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-lg border transition-colors ${
                selectedCategory === null
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border hover:border-primary"
              }`}
            >
              All Categories
            </button>
            {["organic", "mushroom", "dairy", "greenhouse"].map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg border transition-colors capitalize ${
                  selectedCategory === category
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border hover:border-primary"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Learning Modules */}
        <div className="space-y-4">
          {filteredModules.map((module) => (
            <div key={module.id} className="bg-card border border-border rounded-xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-3xl">{module.icon}</span>
                    <div>
                      <h3 className="text-xl font-semibold">{module.title}</h3>
                      <p className="text-sm text-muted-foreground capitalize">{module.category}</p>
                    </div>
                  </div>
                  <p className="text-foreground">{module.content}</p>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setExpandedModule(expandedModule === module.id ? null : module.id)}
                >
                  {expandedModule === module.id ? "Hide" : "View"} Steps
                </Button>
              </div>

              {expandedModule === module.id && (
                <div className="mt-6 pt-6 border-t border-border">
                  <h4 className="font-semibold mb-4">Step-by-Step Guide:</h4>
                  <ol className="space-y-3">
                    {module.steps.map((step, idx) => (
                      <li key={idx} className="flex gap-3">
                        <span className="font-bold text-primary min-w-6">{idx + 1}.</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
