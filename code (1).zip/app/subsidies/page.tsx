"use client"

import { useState } from "react"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Subsidy {
  id: string
  title: string
  description: string
  crops: string[]
  eligibility: string
  amount: string
  link: string
  department: string
}

const subsidies: Subsidy[] = [
  {
    id: "1",
    title: "Agricultural Input Subsidy",
    description: "Subsidy for agricultural inputs like seeds, fertilizers, and tools.",
    crops: ["Rice", "Wheat", "Corn", "Pulses"],
    eligibility: "Small and marginal farmers with land up to 3 hectares",
    amount: "Up to ₹50,000 per farmer",
    link: "https://moad.gov.np",
    department: "Ministry of Agriculture",
  },
  {
    id: "2",
    title: "Irrigation Development Subsidy",
    description: "Support for developing irrigation infrastructure.",
    crops: ["All crops"],
    eligibility: "Farmers with 0.5-5 hectares of land",
    amount: "Up to ₹100,000",
    link: "https://moad.gov.np",
    department: "Ministry of Irrigation",
  },
  {
    id: "3",
    title: "Organic Farming Support",
    description: "Financial support for transitioning to organic farming.",
    crops: ["All crops"],
    eligibility: "Farmers committed to organic practices for 3+ years",
    amount: "Up to ₹75,000 per farmer",
    link: "https://moad.gov.np",
    department: "Ministry of Agriculture",
  },
  {
    id: "4",
    title: "Agricultural Mechanization Subsidy",
    description: "Support for purchasing farm machinery and equipment.",
    crops: ["All crops"],
    eligibility: "Groups of 5+ farmers or farmer cooperatives",
    amount: "Up to 50% of equipment cost",
    link: "https://moad.gov.np",
    department: "Ministry of Agriculture",
  },
]

export default function SubsidiesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [cropFilter, setCropFilter] = useState("all")

  const filteredSubsidies = subsidies.filter((subsidy) => {
    const matchesSearch =
      subsidy.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subsidy.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCrop =
      cropFilter === "all" || subsidy.crops.includes(cropFilter) || subsidy.crops.includes("All crops")
    return matchesSearch && matchesCrop
  })

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Subsidy Finder</h1>

        {/* Search and Filter */}
        <div className="bg-card border border-border rounded-xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Search Subsidies</label>
              <Input
                type="text"
                placeholder="Search by name or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Filter by Crop</label>
              <select
                value={cropFilter}
                onChange={(e) => setCropFilter(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background"
              >
                <option value="all">All Crops</option>
                <option value="Rice">Rice</option>
                <option value="Wheat">Wheat</option>
                <option value="Corn">Corn</option>
                <option value="Pulses">Pulses</option>
              </select>
            </div>
          </div>
        </div>

        {/* Subsidies List */}
        <div className="space-y-6">
          {filteredSubsidies.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No subsidies found matching your criteria</p>
            </div>
          ) : (
            filteredSubsidies.map((subsidy) => (
              <div key={subsidy.id} className="bg-card border border-border rounded-xl p-6">
                <div className="mb-4">
                  <h3 className="text-2xl font-bold mb-2">{subsidy.title}</h3>
                  <p className="text-sm text-primary font-medium">{subsidy.department}</p>
                </div>

                <p className="text-foreground mb-4">{subsidy.description}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <h4 className="font-semibold mb-2">Eligible Crops:</h4>
                    <div className="flex flex-wrap gap-2">
                      {subsidy.crops.map((crop) => (
                        <span key={crop} className="bg-muted px-3 py-1 rounded-full text-sm">
                          {crop}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Amount:</h4>
                    <p className="text-lg text-primary font-bold">{subsidy.amount}</p>
                  </div>
                </div>

                <div className="mb-4">
                  <h4 className="font-semibold mb-2">Eligibility:</h4>
                  <p className="text-foreground">{subsidy.eligibility}</p>
                </div>

                <Button className="bg-primary hover:bg-primary/90" asChild>
                  <a href={subsidy.link} target="_blank" rel="noopener noreferrer">
                    Learn More & Apply
                  </a>
                </Button>
              </div>
            ))
          )}
        </div>

        {/* Subsidy Calculator Section */}
        <div className="mt-12 bg-primary text-primary-foreground rounded-xl p-8">
          <h2 className="text-2xl font-bold mb-4">Subsidy Calculator</h2>
          <p className="mb-6">Calculate potential subsidies based on your farm size and crop type.</p>
          <Button className="bg-primary-foreground hover:bg-primary-foreground/90 text-primary">Open Calculator</Button>
        </div>
      </div>
    </main>
  )
}
