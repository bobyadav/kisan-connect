import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Navbar />

      {/* Hero Section */}
      <section className="bg-background py-24 px-4 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="text-primary">Empower</span> <span className="text-foreground">Your Farming Journey</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
            Real-time market data, AI-powered crop recommendations, and government subsidies at your fingertips.
            Designed for Nepali farmers.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8" asChild>
              <Link href="/signup">Get Started Free</Link>
            </Button>
            <Button size="lg" variant="outline" className="px-8 bg-transparent" asChild>
              <Link href="/market-prices">View Market Prices</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Current Weather Section */}
      <section className="py-20 px-4 bg-background">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12">Current Weather</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                region: "Kathmandu Valley",
                location: "Location",
                temp: "22°C",
                humidity: "65%",
                condition: "Partly Cloudy",
                icon: "⛅",
              },
              {
                region: "Pokhara Region",
                location: "Location",
                temp: "24°C",
                humidity: "72%",
                condition: "Clear",
                icon: "☀️",
              },
              {
                region: "Teral Region",
                location: "Location",
                temp: "28°C",
                humidity: "58%",
                condition: "Clear",
                icon: "☀️",
              },
            ].map((item, idx) => (
              <div key={idx} className="bg-card border border-border rounded-2xl p-8 hover:shadow-md transition-shadow">
                <div className="text-5xl mb-4">{item.icon}</div>
                <h3 className="font-bold text-xl mb-2">{item.region}</h3>
                <p className="text-sm text-muted-foreground mb-6">{item.location}</p>
                <div className="space-y-3">
                  <p className="text-3xl font-bold">{item.temp}</p>
                  <p className="text-sm">
                    Humidity: <span className="font-semibold text-foreground">{item.humidity}</span>
                  </p>
                  <p className="text-sm">
                    Condition: <span className="font-semibold text-foreground">{item.condition}</span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why KisanConnect Section */}
      <section className="py-20 px-4 bg-muted">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Why KisanConnect?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: "📈",
                title: "Live Market Prices",
                desc: "Track real-time prices for your crops and make informed selling decisions.",
              },
              {
                icon: "🌱",
                title: "AI Recommendations",
                desc: "Get personalized crop suggestions based on weather, soil, and market trends.",
              },
              {
                icon: "💰",
                title: "Government Subsidies",
                desc: "Find and apply for agricultural subsidies and government support programs.",
              },
              {
                icon: "🌤️",
                title: "Weather Insights",
                desc: "Get accurate weather forecasts specific to your farming region.",
              },
            ].map((item, idx) => (
              <div key={idx} className="bg-card border border-border rounded-2xl p-8 hover:shadow-md transition-shadow">
                <div className="text-5xl mb-4">{item.icon}</div>
                <h3 className="font-bold text-lg mb-3">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Transform Your Farm?</h2>
          <p className="text-lg mb-10 opacity-90">
            Join thousands of Nepali farmers using KisanConnect to maximize their yields and income.
          </p>
          <Button
            size="lg"
            className="bg-primary-foreground hover:bg-primary-foreground/90 text-primary font-semibold px-8"
            asChild
          >
            <Link href="/signup">Start Your Journey Today</Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            <div>
              <h3 className="font-bold text-lg mb-4">KisanConnect</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Empowering Nepali farmers with modern technology
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Product</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li>
                  <Link href="/market-prices" className="hover:text-primary transition-colors">
                    Market Prices
                  </Link>
                </li>
                <li>
                  <Link href="/subsidies" className="hover:text-primary transition-colors">
                    Subsidies
                  </Link>
                </li>
                <li>
                  <Link href="/learning" className="hover:text-primary transition-colors">
                    AI Insights
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-primary transition-colors">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary transition-colors">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-primary transition-colors">
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary transition-colors">
                    Terms
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>© 2025 KisanConnect. All rights reserved. Built for Nepali farmers.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
