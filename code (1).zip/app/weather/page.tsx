"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/navbar"

interface ForecastDay {
  day: string
  high: number
  low: number
  condition: string
  icon: string
  alert?: string
}

export default function WeatherPage() {
  const [selectedRegion, setSelectedRegion] = useState("Kathmandu Valley")
  const [forecast, setForecast] = useState<ForecastDay[]>([])
  const [loading, setLoading] = useState(true)
  const [currentWeather, setCurrentWeather] = useState({
    temp: 22,
    humidity: 65,
    condition: "Partly Cloudy",
  })

  const regions = ["Kathmandu Valley", "Pokhara Region", "Teral Region", "Hilly Region"]

  useEffect(() => {
    fetchWeather()
  }, [selectedRegion])

  const fetchWeather = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/weather?region=${selectedRegion}`)
      const data = await res.json()
      setCurrentWeather(data.weather || { temp: 22, humidity: 65, condition: "Partly Cloudy" })
      setForecast(data.forecast || generateMockForecast())
    } catch (error) {
      console.error("Failed to fetch weather:", error)
      setForecast(generateMockForecast())
    } finally {
      setLoading(false)
    }
  }

  const generateMockForecast = (): ForecastDay[] => {
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    const conditions = ["Sunny", "Cloudy", "Rainy", "Clear", "Partly Cloudy"]
    return days.map((day) => ({
      day,
      high: Math.floor(Math.random() * 10) + 25,
      low: Math.floor(Math.random() * 10) + 15,
      condition: conditions[Math.floor(Math.random() * conditions.length)],
      icon: "🌤️",
    }))
  }

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">7-Day Weather Forecast</h1>

        {/* Region Selection */}
        <div className="mb-8">
          <label className="text-sm font-medium mb-3 block">Select Region</label>
          <div className="flex gap-3 flex-wrap">
            {regions.map((region) => (
              <button
                key={region}
                onClick={() => setSelectedRegion(region)}
                className={`px-4 py-2 rounded-lg border transition-colors ${
                  selectedRegion === region
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border hover:border-primary"
                }`}
              >
                {region}
              </button>
            ))}
          </div>
        </div>

        {/* Current Weather */}
        <div className="bg-primary text-primary-foreground rounded-xl p-8 mb-8">
          <h2 className="text-2xl font-bold mb-4">{selectedRegion}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm opacity-90 mb-1">Temperature</p>
              <p className="text-4xl font-bold">{currentWeather.temp}°C</p>
            </div>
            <div>
              <p className="text-sm opacity-90 mb-1">Condition</p>
              <p className="text-xl font-semibold">{currentWeather.condition}</p>
            </div>
            <div>
              <p className="text-sm opacity-90 mb-1">Humidity</p>
              <p className="text-2xl font-bold">{currentWeather.humidity}%</p>
            </div>
          </div>
        </div>

        {/* 7-Day Forecast */}
        {loading ? (
          <div className="text-center py-12">Loading forecast...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
            {forecast.map((day, idx) => (
              <div key={idx} className="bg-card border border-border rounded-xl p-4 text-center">
                <p className="font-semibold mb-3">{day.day}</p>
                <p className="text-2xl mb-3">{day.icon}</p>
                <p className="text-sm text-muted-foreground mb-2">{day.condition}</p>
                <div className="flex justify-around text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">High</p>
                    <p className="font-semibold">{day.high}°</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Low</p>
                    <p className="font-semibold">{day.low}°</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Alerts */}
        <div className="mt-8 bg-destructive/10 border border-destructive rounded-xl p-6">
          <h3 className="font-semibold text-lg mb-3">Weather Alerts</h3>
          <ul className="space-y-2 text-sm">
            <li>Rain expected in 2-3 days. Prepare harvesting accordingly.</li>
            <li>Frost alert for Kathmandu Valley on Friday night.</li>
          </ul>
        </div>
      </div>
    </main>
  )
}
