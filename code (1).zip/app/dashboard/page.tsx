"use client"

import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"

export default function DashboardPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [user, loading, router])

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  if (!user) {
    return null
  }

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Welcome, {user.email}</h1>

        {user.role === "farmer" && <FarmerDashboard userId={user.userId} />}
        {user.role === "buyer" && <BuyerDashboard />}
        {user.role === "admin" && <AdminDashboard />}
      </div>
    </main>
  )
}

function FarmerDashboard({ userId }: { userId: string }) {
  return (
    <div className="space-y-8">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Active Crops", value: "0", icon: "🌾" },
          { label: "Total Earnings", value: "₹0", icon: "💰" },
          { label: "Orders", value: "0", icon: "📦" },
          { label: "New Messages", value: "0", icon: "💬" },
        ].map((stat, idx) => (
          <div key={idx} className="bg-card border border-border rounded-xl p-6">
            <div className="text-3xl mb-2">{stat.icon}</div>
            <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
            <p className="text-2xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="bg-card border border-border rounded-xl p-6">
        <h2 className="text-2xl font-bold mb-4">Quick Actions</h2>
        <div className="flex gap-4 flex-wrap">
          <Button className="bg-primary hover:bg-primary/90">List New Crop</Button>
          <Button variant="outline">View Market Prices</Button>
          <Button variant="outline">Check Weather</Button>
          <Button variant="outline">Find Subsidies</Button>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-card border border-border rounded-xl p-6">
        <h2 className="text-2xl font-bold mb-4">Recent Orders</h2>
        <p className="text-muted-foreground">No orders yet. List your crops to start selling!</p>
      </div>
    </div>
  )
}

function BuyerDashboard() {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Active Orders", value: "0", icon: "📦" },
          { label: "Total Spent", value: "₹0", icon: "💳" },
          { label: "Favorites", value: "0", icon: "❤️" },
          { label: "Wishlist", value: "0", icon: "⭐" },
        ].map((stat, idx) => (
          <div key={idx} className="bg-card border border-border rounded-xl p-6">
            <div className="text-3xl mb-2">{stat.icon}</div>
            <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
            <p className="text-2xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-card border border-border rounded-xl p-6">
        <h2 className="text-2xl font-bold mb-4">Browse Crops</h2>
        <Button className="bg-primary hover:bg-primary/90">View Marketplace</Button>
      </div>
    </div>
  )
}

function AdminDashboard() {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Total Users", value: "0", icon: "👥" },
          { label: "Active Crops", value: "0", icon: "🌾" },
          { label: "Orders", value: "0", icon: "📦" },
          { label: "Revenue", value: "₹0", icon: "💹" },
        ].map((stat, idx) => (
          <div key={idx} className="bg-card border border-border rounded-xl p-6">
            <div className="text-3xl mb-2">{stat.icon}</div>
            <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
            <p className="text-2xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-card border border-border rounded-xl p-6">
        <h2 className="text-2xl font-bold mb-4">Admin Actions</h2>
        <div className="flex gap-4 flex-wrap">
          <Button variant="outline">Manage Users</Button>
          <Button variant="outline">Manage Content</Button>
          <Button variant="outline">View Analytics</Button>
          <Button variant="outline">Manage News</Button>
        </div>
      </div>
    </div>
  )
}
