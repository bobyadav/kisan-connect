"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useLanguage } from "@/contexts/language-context"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Crop {
  _id: string
  name: string
  price: number
  weight: number
  location: string
  image?: string
  farmerId: string
  distance: number
  farmerName: string
  rating: number
  reviews: number
  pricePerKg: number
  priceComparison: string
  daysLeft: number
  verified: boolean
  available: boolean
}

export default function MarketplacePage() {
  const [crops, setCrops] = useState<Crop[]>([
    {
      _id: "1",
      name: "Organic Tomatoes",
      price: 45,
      weight: 50,
      location: "Dawa Sherpa",
      farmerId: "farmer1",
      distance: 2.3,
      farmerName: "Dawa Sherpa",
      rating: 4.8,
      reviews: 124,
      pricePerKg: 45,
      priceComparison: "+7% below avg",
      daysLeft: 3,
      verified: true,
      available: true,
    },
    {
      _id: "2",
      name: "Potatoes (Red)",
      price: 28,
      weight: 300,
      location: "Gita Sharma",
      farmerId: "farmer2",
      distance: 5.1,
      farmerName: "Gita Sharma",
      rating: 4.7,
      reviews: 203,
      pricePerKg: 28,
      priceComparison: "+7% below avg",
      daysLeft: 7,
      verified: true,
      available: true,
    },
    {
      _id: "3",
      name: "Local Rice (Basmati)",
      price: 65,
      weight: 200,
      location: "Anita Pradhan",
      farmerId: "farmer3",
      distance: 12.5,
      farmerName: "Anita Pradhan",
      rating: 4.9,
      reviews: 89,
      pricePerKg: 65,
      priceComparison: "+8% below avg",
      daysLeft: 5,
      verified: true,
      available: true,
    },
    {
      _id: "4",
      name: "Onions (White)",
      price: 35,
      weight: 400,
      location: "Ram Kumar",
      farmerId: "farmer4",
      distance: 14.8,
      farmerName: "Ram Kumar",
      rating: 4.5,
      reviews: 142,
      pricePerKg: 35,
      priceComparison: "+9% below avg",
      daysLeft: 10,
      verified: true,
      available: true,
    },
    {
      _id: "5",
      name: "Maize/Corn",
      price: 32,
      weight: 500,
      location: "Bikram Thapa",
      farmerId: "farmer5",
      distance: 35.2,
      farmerName: "Bikram Thapa",
      rating: 4.6,
      reviews: 56,
      pricePerKg: 32,
      priceComparison: "+9% below avg",
      daysLeft: 2,
      verified: true,
      available: true,
    },
    {
      _id: "6",
      name: "Wheat (Premium)",
      price: 52,
      weight: 150,
      location: "Sita Rai",
      farmerId: "farmer6",
      distance: 38.9,
      farmerName: "Sita Rai",
      rating: 4.8,
      reviews: 78,
      pricePerKg: 52,
      priceComparison: "+6% below avg",
      daysLeft: 4,
      verified: true,
      available: true,
    },
  ])

  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [locationFilter, setLocationFilter] = useState("all")
  const [priceFilter, setPriceFilter] = useState("all")
  const [sortFilter, setSortFilter] = useState("nearest")
  const [user, setUser] = useState<any>(null)
  const { t } = useLanguage()

  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
  }, [])

  const deleteCrop = (cropId: string) => {
    if (user?.role === "farmer") {
      setCrops(crops.filter((crop) => crop._id !== cropId))
    }
  }

  const filteredAndSortedCrops = crops
    .filter((crop) => {
      const matchesSearch = crop.name.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesLocation =
        locationFilter === "all" || crop.location.toLowerCase().includes(locationFilter.toLowerCase())
      const matchesPrice = priceFilter === "all"
      return matchesSearch && matchesLocation && matchesPrice
    })
    .sort((a, b) => {
      if (sortFilter === "nearest") return a.distance - b.distance
      if (sortFilter === "cheapest") return a.price - b.price
      if (sortFilter === "rating") return b.rating - a.rating
      return 0
    })

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">{t("crop-marketplace")}</h1>
          <p className="text-muted-foreground">{t("buy-fresh-crops")}</p>
        </div>

        {/* Filters */}
        <div className="bg-card border border-border rounded-xl p-6 mb-8">
          <div className="flex flex-col gap-4">
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="text-sm font-medium mb-2 block">{t("search")}</label>
                <Input
                  type="text"
                  placeholder={`${t("search")} crops, farmer name..`}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">{t("location")}</label>
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder={t("all-locations")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("all-locations")}</SelectItem>
                    <SelectItem value="kathmandu">Kathmandu</SelectItem>
                    <SelectItem value="pokhara">Pokhara</SelectItem>
                    <SelectItem value="biratnagar">Biratnagar</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">{t("price-range")}</label>
                <Select value={priceFilter} onValueChange={setPriceFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder={t("all-prices")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("all-prices")}</SelectItem>
                    <SelectItem value="0-50">₹0 - ₹50</SelectItem>
                    <SelectItem value="50-100">₹50 - ₹100</SelectItem>
                    <SelectItem value="100-500">₹100 - ₹500</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">{t("sort-by")}</label>
                <Select value={sortFilter} onValueChange={setSortFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder={t("nearest-first")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nearest">{t("nearest-first")}</SelectItem>
                    <SelectItem value="cheapest">Cheapest First</SelectItem>
                    <SelectItem value="rating">Highest Rating</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button
                  variant="outline"
                  className="w-full bg-transparent"
                  onClick={() => {
                    setSearchTerm("")
                    setLocationFilter("all")
                    setPriceFilter("all")
                    setSortFilter("nearest")
                  }}
                >
                  {t("reset-filters")}
                </Button>
              </div>
            </div>
          </div>

          <div className="text-sm text-muted-foreground mt-4">{filteredAndSortedCrops.length} crops available</div>
        </div>

        {/* Crops Grid */}
        {loading ? (
          <div className="text-center py-12">Loading crops...</div>
        ) : filteredAndSortedCrops.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">No crops found</p>
            <Button className="bg-primary hover:bg-primary/90">Browse All Crops</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedCrops.map((crop) => (
              <div
                key={crop._id}
                className="bg-card border border-border rounded-2xl overflow-hidden hover:shadow-lg transition-shadow"
              >
                {/* Image with badges */}
                <div className="relative w-full h-48 bg-gradient-to-br from-orange-100 to-orange-50 flex items-center justify-center">
                  <span className="text-6xl">🌾</span>
                  {crop.verified && (
                    <div className="absolute top-3 left-3 bg-orange-500 text-white px-2 py-1 rounded-lg text-xs font-semibold flex items-center gap-1">
                      ✓ {t("verified")}
                    </div>
                  )}
                  {crop.available && (
                    <div className="absolute top-3 right-3 bg-green-500 text-white px-2 py-1 rounded-lg text-xs font-semibold">
                      {t("available")}
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-1">{crop.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex items-center gap-1">📍 {crop.farmerName}</p>

                  {/* Price section */}
                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm text-muted-foreground">{t("price-per-kg")}</span>
                      <span className="text-xs text-amber-600">{crop.priceComparison}</span>
                    </div>
                    <div className="text-2xl font-bold text-primary">₹{crop.pricePerKg}</div>
                  </div>

                  {/* Details grid */}
                  <div className="grid grid-cols-2 gap-3 mb-4 pb-4 border-b border-border">
                    <div className="text-sm">
                      <span className="text-muted-foreground">{crop.weight}kg</span>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">
                        📍 {crop.distance} {t("km-away")}
                      </span>
                    </div>
                    <div className="text-sm flex items-center gap-1">
                      <span>⭐ {crop.rating}</span>
                      <span className="text-muted-foreground">({crop.reviews})</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      📅 {crop.daysLeft} {t("days-left")}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="outline" size="sm" className="w-full text-xs bg-transparent">
                        💬 {t("chat")}
                      </Button>
                      <Button variant="outline" size="sm" className="w-full text-xs bg-transparent">
                        ☎️ {t("call")}
                      </Button>
                    </div>
                    <Button className="w-full bg-amber-500 hover:bg-amber-600 text-white font-semibold">
                      {t("book-order")}
                    </Button>

                    {user?.role === "farmer" && user?._id === crop.farmerId && (
                      <Button
                        variant="destructive"
                        size="sm"
                        className="w-full text-xs"
                        onClick={() => deleteCrop(crop._id)}
                      >
                        {t("delete-crop")}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  )
}
