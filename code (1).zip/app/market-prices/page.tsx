"use client"

import { useState } from "react"
import Navbar from "@/components/navbar"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/contexts/language-context"

interface MarketPrice {
  crop: string
  district: string
  price: number
  source: string
}

const priceChartData = [
  { day: "Mon", rice: 45, wheat: 28, corn: 22 },
  { day: "Tue", rice: 48, wheat: 30, corn: 24 },
  { day: "Wed", rice: 46, wheat: 29, corn: 23 },
  { day: "Thu", rice: 52, wheat: 35, corn: 26 },
  { day: "Fri", rice: 55, wheat: 38, corn: 28 },
  { day: "Sat", rice: 58, wheat: 40, corn: 30 },
  { day: "Sun", rice: 60, wheat: 42, corn: 32 },
]

const samplePrices: MarketPrice[] = [
  { crop: "Rice", district: "Kathmandu", price: 60, source: "MOAD" },
  { crop: "Wheat", district: "Kathmandu", price: 42, source: "MOAD" },
  { crop: "Corn", district: "Kathmandu", price: 32, source: "MOAD" },
  { crop: "Lentils", district: "Pokhara", price: 95, source: "MOAD" },
  { crop: "Potatoes", district: "Pokhara", price: 28, source: "MOAD" },
  { crop: "Tomatoes", district: "Teral", price: 45, source: "MOAD" },
]

export default function MarketPricesPage() {
  const [prices, setPrices] = useState<MarketPrice[]>(samplePrices)
  const [loading, setLoading] = useState(false)
  const [cropFilter, setCropFilter] = useState("")
  const [districtFilter, setDistrictFilter] = useState("all")
  const { t } = useLanguage()

  const filteredPrices = prices.filter((price) => {
    const matchesCrop = price.crop.toLowerCase().includes(cropFilter.toLowerCase())
    const matchesDistrict =
      districtFilter === "all" || price.district.toLowerCase().includes(districtFilter.toLowerCase())
    return matchesCrop && matchesDistrict
  })

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-2">{t("market-prices")}</h1>
        <p className="text-muted-foreground mb-8">Real-time crop prices updated hourly</p>

        {/* Chart Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Price Trends (Weekly)</CardTitle>
            <CardDescription>Historical price movements for major crops</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={priceChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip formatter={(value) => `₹${value}`} />
                <Legend />
                <Line type="monotone" dataKey="rice" stroke="hsl(var(--chart-1))" name="Rice (₹/kg)" strokeWidth={2} />
                <Line
                  type="monotone"
                  dataKey="wheat"
                  stroke="hsl(var(--chart-2))"
                  name="Wheat (₹/kg)"
                  strokeWidth={2}
                />
                <Line type="monotone" dataKey="corn" stroke="hsl(var(--chart-3))" name="Corn (₹/kg)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Filters */}
        <div className="bg-card border border-border rounded-xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Search Crop</label>
              <Input
                type="text"
                placeholder="Rice, Wheat, Corn..."
                value={cropFilter}
                onChange={(e) => setCropFilter(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">District</label>
              <Select value={districtFilter} onValueChange={setDistrictFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Select district" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Districts</SelectItem>
                  <SelectItem value="Kathmandu">Kathmandu</SelectItem>
                  <SelectItem value="Pokhara">Pokhara</SelectItem>
                  <SelectItem value="Teral">Teral</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Prices Table */}
        {loading ? (
          <div className="text-center py-12">Loading market prices...</div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted border-b border-border">
                <tr>
                  <th className="px-6 py-3 text-left font-semibold">Crop</th>
                  <th className="px-6 py-3 text-left font-semibold">District</th>
                  <th className="px-6 py-3 text-left font-semibold">Price (₹/kg)</th>
                  <th className="px-6 py-3 text-left font-semibold">Source</th>
                </tr>
              </thead>
              <tbody>
                {filteredPrices.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-4 text-center text-muted-foreground">
                      No market prices available
                    </td>
                  </tr>
                ) : (
                  filteredPrices.map((price, idx) => (
                    <tr key={idx} className="border-b border-border hover:bg-muted/50 transition-colors">
                      <td className="px-6 py-4 font-medium">{price.crop}</td>
                      <td className="px-6 py-4">{price.district}</td>
                      <td className="px-6 py-4 text-primary font-semibold">₹{price.price}</td>
                      <td className="px-6 py-4 text-sm text-muted-foreground">{price.source}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </main>
  )
}
