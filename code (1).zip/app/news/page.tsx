"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/navbar"

interface NewsItem {
  id: string
  title: string
  content: string
  source: string
  image?: string
  timestamp: Date
  category: string
}

export default function NewsPage() {
  const [news, setNews] = useState<NewsItem[]>([])
  const [loading, setLoading] = useState(true)
  const [categoryFilter, setCategoryFilter] = useState("all")

  useEffect(() => {
    fetchNews()
    // Refresh news every hour
    const interval = setInterval(fetchNews, 3600000)
    return () => clearInterval(interval)
  }, [])

  const fetchNews = async () => {
    try {
      // TODO: Fetch news from API
      setNews(generateMockNews())
    } catch (error) {
      console.error("Failed to fetch news:", error)
    } finally {
      setLoading(false)
    }
  }

  const generateMockNews = (): NewsItem[] => [
    {
      id: "1",
      title: "Government Announces New Agricultural Subsidy Program",
      content: "The Ministry of Agriculture has announced a new subsidy program targeting small-scale farmers.",
      source: "Ministry of Agriculture",
      timestamp: new Date(),
      category: "government",
    },
    {
      id: "2",
      title: "Market Prices Rise for Organic Vegetables",
      content: "Organic vegetable prices have increased by 15% this month due to high demand.",
      source: "Nepal Agricultural Market",
      timestamp: new Date(Date.now() - 3600000),
      category: "market",
    },
  ]

  const filteredNews = categoryFilter === "all" ? news : news.filter((item) => item.category === categoryFilter)

  const categories = ["all", "government", "market", "weather", "technology"]

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Agricultural News</h1>

        {/* Category Filter */}
        <div className="mb-8 flex gap-2 flex-wrap">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-4 py-2 rounded-lg border transition-colors capitalize ${
                categoryFilter === cat
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border hover:border-primary"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* News List */}
        {loading ? (
          <div className="text-center py-12">Loading news...</div>
        ) : (
          <div className="space-y-6">
            {filteredNews.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No news available</p>
              </div>
            ) : (
              filteredNews.map((item) => (
                <article
                  key={item.id}
                  className="bg-card border border-border rounded-xl p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-xs font-semibold text-primary uppercase">{item.category}</span>
                    <span className="text-xs text-muted-foreground">{item.timestamp.toLocaleDateString()}</span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-foreground mb-4">{item.content}</p>
                  <p className="text-sm text-muted-foreground">Source: {item.source}</p>
                </article>
              ))
            )}
          </div>
        )}
      </div>
    </main>
  )
}
