"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

type Language = "en" | "ne"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

const translations: Record<Language, Record<string, string>> = {
  en: {
    "market-prices": "Market Prices",
    marketplace: "Marketplace",
    weather: "Weather",
    subsidies: "Subsidies",
    profile: "Profile",
    login: "Login",
    signup: "Sign Up",
    search: "Search",
    location: "Location",
    "price-range": "Price Range",
    "sort-by": "Sort By",
    "all-locations": "All Locations",
    "all-prices": "All Prices",
    "nearest-first": "Nearest First",
    "reset-filters": "Reset Filters",
    verified: "Verified",
    available: "Available",
    "price-per-kg": "Price per kg",
    "km-away": "km away",
    "below-avg": "below avg",
    chat: "Chat",
    call: "Call",
    "book-order": "Book Order",
    "add-crop": "Add Crop",
    "delete-crop": "Delete Crop",
    "my-crops": "My Crops",
    "seller-name": "Seller Name",
    "days-left": "days left",
    "crop-marketplace": "Crop Marketplace",
    "buy-fresh-crops": "Buy fresh crops directly from farmers near you. Smart sorting shows nearby farmers first.",
  },
  ne: {
    "market-prices": "बजार मूल्य",
    marketplace: "बजारस्थान",
    weather: "मौसम",
    subsidies: "अनुदान",
    profile: "प्रोफाइल",
    login: "लगइन",
    signup: "साइन अप",
    search: "खोज्नुहोस्",
    location: "स्थान",
    "price-range": "मूल्य दायरा",
    "sort-by": "द्वारा क्रमबद्ध गर्नुहोस्",
    "all-locations": "सबै स्थान",
    "all-prices": "सबै मूल्य",
    "nearest-first": "नजिकको पहिले",
    "reset-filters": "फिल्टरहरू रीसेट गर्नुहोस्",
    verified: "प्रमाणित",
    available: "उपलब्ध",
    "price-per-kg": "किलोग्राम प्रति मूल्य",
    "km-away": "किमी टाढा",
    "below-avg": "औसत भन्दा कम",
    chat: "चर्चा",
    call: "कल",
    "book-order": "अर्डर बुक गर्नुहोस्",
    "add-crop": "बाली थप्नुहोस्",
    "delete-crop": "बाली हटाउनुहोस्",
    "my-crops": "मेरा बाली",
    "seller-name": "विक्रेता नाम",
    "days-left": "दिन बाँकी",
    "crop-marketplace": "बाली बजारस्थान",
    "buy-fresh-crops": "आपके पास के पास के किसानों से सीधे ताजी फसलें खरीदें। स्मार्ट सॉर्टिंग पहले पास के किसानों को दिखाता है।",
  },
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const savedLang = localStorage.getItem("language") as Language | null
    if (savedLang) {
      setLanguage(savedLang)
    }
  }, [])

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang)
    localStorage.setItem("language", lang)
  }

  const t = (key: string): string => {
    return translations[language][key] || translations.en[key] || key
  }

  if (!mounted) return <>{children}</>

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider")
  }
  return context
}
