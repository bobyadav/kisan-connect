// JWT authentication utility functions
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production"

export interface UserPayload {
  userId: string
  email: string
  role: "farmer" | "buyer" | "admin"
}

export function generateToken(payload: UserPayload, expiresIn = "7d"): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn })
}

export function verifyToken(token: string): UserPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as UserPayload
  } catch (error) {
    return null
  }
}

export function decodeToken(token: string): UserPayload | null {
  try {
    return jwt.decode(token) as UserPayload
  } catch (error) {
    return null
  }
}
